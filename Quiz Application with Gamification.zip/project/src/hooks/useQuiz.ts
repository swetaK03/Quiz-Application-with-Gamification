import { useState, useEffect, useCallback } from 'react';
import { Question, QuizState, QuizStats } from '../types/quiz';
import { fallbackQuestions } from '../data/fallbackQuestions';

export const useQuiz = () => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [quizState, setQuizState] = useState<QuizState>({
    currentQuestionIndex: 0,
    score: 0,
    answers: [],
    isComplete: false,
    streak: 0,
    timePerQuestion: [],
  });
  const [startTime, setStartTime] = useState<number>(0);
  const [usingFallback, setUsingFallback] = useState(false);

  const fetchQuizData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Immediately set fallback questions to ensure content is available
      setQuestions(fallbackQuestions);
      setUsingFallback(true);

      // Try to fetch online questions in the background
      const response = await fetch('https://api.jsonserve.com/Uw5CrX', {
        headers: {
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (Array.isArray(data) && data.length > 0 && data.every(q => 
        q.id && 
        typeof q.question === 'string' && 
        Array.isArray(q.options) && 
        typeof q.correctAnswer === 'number' &&
        typeof q.points === 'number'
      )) {
        setQuestions(data);
        setUsingFallback(false);
      }
    } catch (err) {
      console.log('Using fallback questions due to API error');
      // We don't set an error state anymore since we're already using fallback questions
    } finally {
      setLoading(false);
      setStartTime(Date.now());
    }
  }, []);

  useEffect(() => {
    fetchQuizData();
  }, [fetchQuizData]);

  const submitAnswer = (answerIndex: number) => {
    const currentQuestion = questions[quizState.currentQuestionIndex];
    const isCorrect = answerIndex === currentQuestion.correctAnswer;
    const timeSpent = (Date.now() - startTime) / 1000;

    setQuizState(prev => ({
      ...prev,
      score: isCorrect ? prev.score + currentQuestion.points : prev.score,
      streak: isCorrect ? prev.streak + 1 : 0,
      answers: [...prev.answers, answerIndex],
      timePerQuestion: [...prev.timePerQuestion, timeSpent],
      currentQuestionIndex: prev.currentQuestionIndex + 1,
      isComplete: prev.currentQuestionIndex === questions.length - 1,
    }));

    setStartTime(Date.now());
  };

  const calculateStats = (): QuizStats => {
    const correctAnswers = quizState.answers.reduce(
      (count, answer, index) => (answer === questions[index].correctAnswer ? count + 1 : count),
      0
    );

    return {
      totalQuestions: questions.length,
      correctAnswers,
      averageTime: quizState.timePerQuestion.reduce((a, b) => a + b, 0) / questions.length,
      longestStreak: quizState.streak,
      totalScore: quizState.score,
      accuracy: (correctAnswers / questions.length) * 100,
    };
  };

  return {
    questions,
    loading,
    error,
    quizState,
    submitAnswer,
    calculateStats,
    retryFetch: fetchQuizData,
    usingFallback
  };
};