import React from 'react';
import { Trophy, Clock, Target, Zap } from 'lucide-react';
import { QuizStats } from '../types/quiz';

interface QuizResultsProps {
  stats: QuizStats;
  onRestart: () => void;
}

export const QuizResults: React.FC<QuizResultsProps> = ({ stats, onRestart }) => {
  return (
    <div className="w-full max-w-2xl bg-white rounded-xl shadow-lg p-8">
      <h2 className="text-2xl font-bold text-center mb-8">Quiz Complete! 🎉</h2>

      <div className="grid grid-cols-2 gap-6 mb-8">
        <div className="bg-blue-50 p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Trophy className="w-5 h-5 text-blue-600" />
            <span className="font-medium text-gray-700">Score</span>
          </div>
          <p className="text-2xl font-bold text-blue-600">{stats.totalScore}</p>
        </div>

        <div className="bg-green-50 p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-5 h-5 text-green-600" />
            <span className="font-medium text-gray-700">Accuracy</span>
          </div>
          <p className="text-2xl font-bold text-green-600">{stats.accuracy.toFixed(1)}%</p>
        </div>

        <div className="bg-purple-50 p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-5 h-5 text-purple-600" />
            <span className="font-medium text-gray-700">Avg. Time</span>
          </div>
          <p className="text-2xl font-bold text-purple-600">{stats.averageTime.toFixed(1)}s</p>
        </div>

        <div className="bg-orange-50 p-4 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-5 h-5 text-orange-600" />
            <span className="font-medium text-gray-700">Best Streak</span>
          </div>
          <p className="text-2xl font-bold text-orange-600">{stats.longestStreak}</p>
        </div>
      </div>

      <div className="text-center">
        <button
          onClick={onRestart}
          className="bg-blue-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-blue-700 
                   transition-colors duration-200"
        >
          Try Again
        </button>
      </div>
    </div>
  );
};