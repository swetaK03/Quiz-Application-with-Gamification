export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  points: number;
}

export interface QuizState {
  currentQuestionIndex: number;
  score: number;
  answers: number[];
  isComplete: boolean;
  streak: number;
  timePerQuestion: number[];
}

export interface QuizStats {
  totalQuestions: number;
  correctAnswers: number;
  averageTime: number;
  longestStreak: number;
  totalScore: number;
  accuracy: number;
}