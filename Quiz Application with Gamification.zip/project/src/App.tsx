import React from 'react';
import { useQuiz } from './hooks/useQuiz';
import { QuizCard } from './components/QuizCard';
import { QuizResults } from './components/QuizResults';
import { Brain, RefreshCw, AlertCircle } from 'lucide-react';

function App() {
  const { questions, loading, error, quizState, submitAnswer, calculateStats, retryFetch, usingFallback } = useQuiz();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent mb-4 mx-auto"></div>
          <p className="text-gray-600">Loading quiz questions...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-4">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <p className="text-red-500 font-medium mb-4">{error}</p>
            <button
              onClick={retryFetch}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 flex items-center justify-center gap-2 w-full"
            >
              <RefreshCw className="w-4 h-4" />
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!questions || questions.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500 font-medium mb-4">No questions available</p>
          <button
            onClick={retryFetch}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {!quizState.isComplete ? (
          <div className="space-y-8">
            <div className="text-center mb-12">
              <div className="flex items-center justify-center gap-3 mb-4">
                <Brain className="w-8 h-8 text-blue-600" />
                <h1 className="text-3xl font-bold text-gray-900">Knowledge Quest</h1>
              </div>
              <p className="text-gray-600">Test your knowledge and earn points!</p>
              {usingFallback && (
                <div className="mt-4 flex items-center justify-center gap-2 text-amber-600">
                  <AlertCircle className="w-5 h-5" />
                  <p className="text-sm">Using offline questions. Click retry to try loading online content.</p>
                  <button
                    onClick={retryFetch}
                    className="ml-2 text-blue-600 hover:text-blue-700 text-sm font-medium"
                  >
                    Retry
                  </button>
                </div>
              )}
            </div>

            <div className="flex justify-center">
              <QuizCard
                question={questions[quizState.currentQuestionIndex]}
                onAnswer={submitAnswer}
                questionNumber={quizState.currentQuestionIndex}
                totalQuestions={questions.length}
              />
            </div>

            <div className="fixed bottom-0 left-0 w-full bg-white border-t py-4">
              <div className="max-w-7xl mx-auto px-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <span className="text-sm font-medium text-gray-500">
                      Score: {quizState.score}
                    </span>
                    <span className="text-sm font-medium text-gray-500">
                      Streak: {quizState.streak}
                    </span>
                  </div>
                  <div className="w-64 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-600 transition-all duration-300"
                      style={{
                        width: `${(quizState.currentQuestionIndex / questions.length) * 100}%`,
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex justify-center">
            <QuizResults
              stats={calculateStats()}
              onRestart={retryFetch}
            />
          </div>
        )}
      </div>
    </div>
  );
}

export default App;